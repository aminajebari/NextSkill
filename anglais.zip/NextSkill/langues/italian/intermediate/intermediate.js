// Dati delle lezioni per il livello intermedio
const lessonsData = [
    {
        id: 1,
        title: "Tempi passati - Parte 1",
        description: "Impara a usare il simple past e il present perfect.",
        duration: "20 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Tempi passati - Parte 2",
        description: "Padroneggia il past continuous e il past perfect.",
        duration: "25 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Condizionale e ipotesi",
        description: "Esprimi condizioni e ipotesi in inglese.",
        duration: "22 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Phrasal verbs comuni",
        description: "Scopri i verbi frasali più utilizzati.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 40
    },
    {
        id: 5,
        title: "Conversazioni telefoniche",
        description: "Impara a comunicare efficacemente al telefono.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 20
    },
    {
        id: 6,
        title: "Esprimere la propria opinione",
        description: "Tecniche per esprimere le tue opinioni chiaramente.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Descrivere esperienze",
        description: "Racconta le tue esperienze personali e professionali.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Vocabolario degli affari",
        description: "Termini essenziali per il mondo professionale.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Comprensione orale avanzata",
        description: "Migliora l'ascolto con dialoghi complessi.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Discorso indiretto",
        description: "Impara a riportare le parole di qualcuno.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Scrittura formale",
        description: "Scrivi email e lettere professionali.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Modi di dire ed espressioni",
        description: "Scopri le espressioni idiomatiche comuni.",
        duration: "25 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Pronuncia avanzata",
        description: "Perfeziona il tuo accento e intonazione.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Conversazioni in contesto sociale",
        description: "Interagisci in varie situazioni sociali.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Vocabolario tecnico",
        description: "Termini specializzati secondo i tuoi interessi.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "Comprensione di testi complessi",
        description: "Analizza articoli e testi avanzati.",
        duration: "32 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Dibattiti e discussioni",
        description: "Partecipa attivamente a dibattiti in inglese.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Cultura anglofona",
        description: "Scopri le sfumature culturali dei paesi anglofoni.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Preparazione ai colloqui",
        description: "Preparati per colloqui in inglese.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Ripasso generale intermedio",
        description: "Metti alla prova le tue conoscenze con esercizi di sintesi.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Elementi DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    console.log("Pagina Intermedio caricata!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendering delle lezioni
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Creazione di una carta lezione
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completata' : lesson.locked ? 'Bloccata' : 'In Corso';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'medium' ? 'Medio' : 'Difficile';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Bloccata</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Rivedi</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Rifai</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continua' : 'Inizia'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Aggiornamento del progresso globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lezioni completate`;
}

// Iniziare una lezione
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Inizio lezione: ${lesson.title}`);
    
    // Simulazione del progresso
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuare una lezione
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Ripresa lezione: ${lesson.title}\n\nStai continuando al ${lesson.progress}% di progresso.`);
}

// Rivedere una lezione
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Revisione lezione: ${lesson.title}\n\nQuesta funzione ti permette di rivedere i contenuti già appresi.`);
}

// Configurazione degli event listener
function setupEventListeners() {
    // Filtri
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Ottenere il filtro corrente
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Funzione per segnare una lezione come completata (per test)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Sbloccare la lezione successiva se esiste
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ Congratulazioni! Hai completato la lezione "${lesson.title}"`);
    }
}

// Funzione per sbloccare tutte le lezioni (per test)
function unlockAllLessons() {
    if (confirm("Vuoi sbloccare tutte le lezioni? (Funzione di test)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("Tutte le lezioni sono state sbloccate!");
    }
}

// Aggiungere queste funzioni alla console per i test
console.log(`Funzioni disponibili:
- completeLesson(lessonId) : Segna una lezione come completata
- unlockAllLessons() : Sblocca tutte le lezioni
`);