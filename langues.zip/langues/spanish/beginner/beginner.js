// Datos de las lecciones para el nivel principiante
const lessonsData = [
    {
        id: 1,
        title: "Alfabeto y pronunciación",
        description: "Aprende el alfabeto inglés y la pronunciación correcta.",
        duration: "15 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Saludos y presentaciones",
        description: "Cómo saludar y presentarse en inglés.",
        duration: "20 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Números y colores",
        description: "Aprende los números del 1 al 100 y los colores principales.",
        duration: "18 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Artículos y plurales",
        description: "Uso correcto de 'a', 'an', 'the' y formación de plurales.",
        duration: "22 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 60
    },
    {
        id: 5,
        title: "Verbo 'to be'",
        description: "Conjugación y uso del verbo ser/estar.",
        duration: "25 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 6,
        title: "Pronombres personales",
        description: "I, you, he, she, it, we, they - uso correcto.",
        duration: "20 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Presente simple",
        description: "Formación y uso del present simple.",
        duration: "28 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Vocabulario: familia",
        description: "Términos para describir la familia y las relaciones.",
        duration: "18 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Preposiciones de lugar",
        description: "In, on, at, under, next to - uso correcto.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Adjetivos posesivos",
        description: "My, your, his, her, its, our, their.",
        duration: "20 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Preguntas con 'do/does'",
        description: "Cómo formular preguntas en presente simple.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Vocabulario: comida y bebidas",
        description: "Términos para ordenar en restaurantes y hacer compras.",
        duration: "22 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Adverbios de frecuencia",
        description: "Always, often, sometimes, never - posición y uso.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "There is / There are",
        description: "Expresar existencia y cantidad.",
        duration: "18 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Repaso general",
        description: "Ejercicios de síntesis para consolidar conocimientos.",
        duration: "30 min",
        difficulty: "medium",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Elementos DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    console.log("¡Página Principiante cargada!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Renderizado de lecciones
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Creación de una tarjeta de lección
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completada' : lesson.locked ? 'Bloqueada' : 'En Progreso';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'easy' ? 'difficulty-easy' : lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'easy' ? 'Fácil' : lesson.difficulty === 'medium' ? 'Medio' : 'Difícil';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Bloqueada</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Revisar</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Rehacer</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continuar' : 'Comenzar'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Actualización del progreso global
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lecciones completadas`;
}

// Comenzar una lección
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Comenzando lección: ${lesson.title}`);
    
    // Simulación de progreso
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuar una lección
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Continuando lección: ${lesson.title}\n\nEstás continuando al ${lesson.progress}% de progreso.`);
}

// Revisar una lección
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Revisando lección: ${lesson.title}\n\nEsta función te permite revisar contenido ya aprendido.`);
}

// Configuración de event listeners
function setupEventListeners() {
    // Filtros
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Obtener el filtro actual
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Función para marcar una lección como completada (para pruebas)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Desbloquear la siguiente lección si existe
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ ¡Felicidades! Has completado la lección "${lesson.title}"`);
    }
}

// Función para desbloquear todas las lecciones (para pruebas)
function unlockAllLessons() {
    if (confirm("¿Quieres desbloquear todas las lecciones? (Función de prueba)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("¡Todas las lecciones han sido desbloqueadas!");
    }
}

// Añadir estas funciones a la consola para pruebas
console.log(`Funciones disponibles:
- completeLesson(lessonId) : Marcar una lección como completada
- unlockAllLessons() : Desbloquear todas las lecciones
`);