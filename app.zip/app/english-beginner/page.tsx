'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Clock, Star, Lock, CheckCircle2, PlayCircle } from 'lucide-react'

const lessonsData = [
  {
    id: 1,
    title: "Basic Greetings",
    description: "Learn how to say hello, goodbye and introduce yourself in English.",
    duration: "10 min",
    difficulty: "easy",
    completed: true,
    locked: false,
    progress: 100
  },
  {
    id: 2,
    title: "Alphabet and Pronunciation",
    description: "Master the English alphabet and basic sounds.",
    duration: "15 min",
    difficulty: "easy",
    completed: true,
    locked: false,
    progress: 100
  },
  {
    id: 3,
    title: "Numbers 1 to 20",
    description: "Count up to 20 and use numbers in simple sentences.",
    duration: "12 min",
    difficulty: "easy",
    completed: true,
    locked: false,
    progress: 100
  },
  {
    id: 4,
    title: "Colors",
    description: "Name and use basic colors in English.",
    duration: "10 min",
    difficulty: "easy",
    completed: true,
    locked: false,
    progress: 100
  },
  {
    id: 5,
    title: "Animals",
    description: "Discover vocabulary for common animals.",
    duration: "15 min",
    difficulty: "easy",
    completed: true,
    locked: false,
    progress: 100
  },
  {
    id: 6,
    title: "Family",
    description: "Learn to talk about family members.",
    duration: "18 min",
    difficulty: "medium",
    completed: false,
    locked: false,
    progress: 60
  },
  {
    id: 7,
    title: "Food and Drinks",
    description: "Essential vocabulary for ordering at restaurants.",
    duration: "20 min",
    difficulty: "medium",
    completed: false,
    locked: false,
    progress: 30
  },
  {
    id: 8,
    title: "Days of the Week",
    description: "Learn the days and talk about your routine.",
    duration: "12 min",
    difficulty: "easy",
    completed: false,
    locked: false,
    progress: 0
  },
  {
    id: 9,
    title: "Months and Seasons",
    description: "Talk about dates and periods of the year.",
    duration: "15 min",
    difficulty: "easy",
    completed: false,
    locked: false,
    progress: 0
  },
  {
    id: 10,
    title: "Present Simple",
    description: "Master the basics of English conjugation.",
    duration: "25 min",
    difficulty: "medium",
    completed: false,
    locked: false,
    progress: 0
  },
]

export default function EnglishBeginnerPage() {
  const [lessons, setLessons] = useState(lessonsData)
  const [filter, setFilter] = useState('all')

  const completedLessons = lessons.filter(lesson => lesson.completed).length
  const totalLessons = lessons.length
  const progress = Math.round((completedLessons / totalLessons) * 100)

  const filteredLessons = lessons.filter(lesson => {
    if (filter === 'completed') return lesson.completed
    if (filter === 'pending') return !lesson.completed && !lesson.locked
    return true
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-600 via-purple-600 to-violet-700">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="inline-flex items-center text-white hover:text-white/80 transition-colors mb-4">
            <ArrowLeft className="mr-2" size={20} />
            Back to Home
          </Link>
          <div className="text-white">
            <div className="text-sm mb-2">Home {">"} English {">"} Beginner</div>
            <h1 className="text-4xl font-bold mb-2">Beginner Level - English</h1>
            <p className="text-white/90">Learn the basics of English with our interactive lessons</p>
            
            {/* Progress Section */}
            <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-xl p-6">
              <div className="flex justify-between items-center mb-3">
                <span className="text-white font-semibold">Overall Progress: {progress}%</span>
                <span className="text-white/90">{completedLessons}/{totalLessons} lessons completed</span>
              </div>
              <div className="w-full h-3 bg-white/20 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-400 transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filter Buttons */}
        <div className="flex gap-2 mb-8 bg-white rounded-lg p-1 w-fit">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-md font-medium transition-colors ${
              filter === 'all' ? 'bg-indigo-600 text-white' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-md font-medium transition-colors ${
              filter === 'completed' ? 'bg-indigo-600 text-white' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-4 py-2 rounded-md font-medium transition-colors ${
              filter === 'pending' ? 'bg-indigo-600 text-white' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Pending
          </button>
        </div>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLessons.map((lesson) => (
            <div
              key={lesson.id}
              className={`bg-white rounded-xl p-6 relative overflow-hidden transition-all hover:shadow-lg ${
                lesson.completed ? 'border-l-4 border-green-500' :
                lesson.locked ? 'border-l-4 border-gray-400 opacity-70' :
                'border-l-4 border-orange-500'
              }`}
            >
              {/* Progress Badge */}
              {lesson.progress > 0 && !lesson.completed && (
                <div className="absolute top-0 right-0 bg-indigo-600 text-white px-3 py-1 rounded-bl-lg text-sm font-semibold">
                  {lesson.progress}%
                </div>
              )}

              {/* Lesson Header */}
              <div className="flex items-start justify-between mb-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                  lesson.completed ? 'bg-green-500' :
                  lesson.locked ? 'bg-gray-400' :
                  'bg-orange-500'
                }`}>
                  {lesson.id}
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                  lesson.completed ? 'bg-green-100 text-green-700' :
                  lesson.locked ? 'bg-gray-100 text-gray-600' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {lesson.completed ? 'Completed' : lesson.locked ? 'Locked' : 'In Progress'}
                </span>
              </div>

              {/* Lesson Content */}
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{lesson.title}</h3>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{lesson.description}</p>

              {/* Lesson Meta */}
              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <div className="flex items-center gap-1">
                  <Clock size={16} />
                  <span>{lesson.duration}</span>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-semibold ${
                  lesson.difficulty === 'easy' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                }`}>
                  {lesson.difficulty === 'easy' ? 'Easy' : 'Medium'}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                {lesson.locked ? (
                  <button disabled className="flex-1 bg-gray-300 text-gray-600 py-2 rounded-lg font-medium cursor-not-allowed flex items-center justify-center gap-2">
                    <Lock size={16} />
                    Locked
                  </button>
                ) : lesson.completed ? (
                  <>
                    <button className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                      Review
                    </button>
                    <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors">
                      Redo
                    </button>
                  </>
                ) : (
                  <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2">
                    <PlayCircle size={16} />
                    {lesson.progress > 0 ? 'Continue' : 'Start'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
