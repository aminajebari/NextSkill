// Données de progression pour chaque niveau (conservées pour l'affichage)
let progressionData = {
    debutant: {
        pourcentage: 25,
        leconsTotal: 20,
        leconsCompletees: 5
    },
    intermediaire: {
        pourcentage: 15,
        leconsTotal: 25,
        leconsCompletees: 4
    },
    avance: {
        pourcentage: 5,
        leconsTotal: 30,
        leconsCompletees: 2
    }
};

// Attendre que le DOM soit complètement chargé
document.addEventListener('DOMContentLoaded', function() {
    console.log("Next Skill - Page chargée avec succès !");
    
    // Initialiser les barres de progression (affichage seulement)
    initialiserProgressions();
    
    // Sélectionner tous les boutons de niveau
    const levelButtons = document.querySelectorAll('.btn-level');
    const levelCards = document.querySelectorAll('.level-card');
    
    // Ajouter un événement click à chaque bouton
    levelButtons.forEach(button => {
        button.addEventListener('click', function() {
            const niveau = this.getAttribute('data-level');
            // Redirection directe sans message
            if (niveau === 'debutant') {
                window.location.href = 'debutant/debutant.html';
            } else if (niveau === 'intermediaire') {
                // Pour l'instant, rediriger vers la même page ou montrer un message
                alert('Niveau Intermédiaire - Bientôt disponible !');
            } else if (niveau === 'avance') {
                alert('Niveau Avancé - Bientôt disponible !');
            }
        });
    });
    
    // Ajouter des effets au survol des cartes
    levelCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.cursor = 'pointer';
        });
        
        // Permettre de cliquer sur toute la carte (sauf pour débutant qui redirige directement)
        card.addEventListener('click', function(e) {
            // Ne pas déclencher si on clique sur le bouton
            if (e.target.classList.contains('btn-level')) return;
            
            const niveau = this.getAttribute('data-level');
            if (niveau === 'debutant') {
                window.location.href = 'debutant/debutant.html';
            } else if (niveau === 'intermediaire') {
                alert('Niveau Intermédiaire - Bientôt disponible !');
            } else if (niveau === 'avance') {
                alert('Niveau Avancé - Bientôt disponible !');
            }
        });
    });
    
    // Animation d'entrée des cartes
    setTimeout(() => {
        levelCards.forEach((card, index) => {
            setTimeout(() => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'all 0.5s ease';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100);
            }, index * 200);
        });
    }, 500);
});

// Fonction pour initialiser les progressions (affichage seulement)
function initialiserProgressions() {
    for (const niveau in progressionData) {
        mettreAJourProgressBar(niveau, progressionData[niveau].pourcentage);
    }
}

// Fonction pour mettre à jour une barre de progression (affichage seulement)
function mettreAJourProgressBar(niveau, pourcentage) {
    const progressFill = document.getElementById(`progress-fill-${niveau}`);
    const progressPercent = document.getElementById(`progress-${niveau}`);
    
    if (progressFill && progressPercent) {
        progressFill.style.width = `${pourcentage}%`;
        progressPercent.textContent = `${pourcentage}%`;
    }
}