// Lessons data for the advanced level
const lessonsData = [
    {
        id: 1,
        title: "Academic Writing",
        description: "Master formal writing for academic publications.",
        duration: "40 min",
        difficulty: "expert",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Complex Negotiations",
        description: "Advanced techniques for business negotiations.",
        duration: "35 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 3,
        title: "Executive Presentations",
        description: "Present effectively to demanding audiences.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 4,
        title: "Literary Analysis",
        description: "Analyze literary works in English.",
        duration: "50 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 5,
        title: "Diplomatic Language",
        description: "Communicate with precision in diplomatic contexts.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 6,
        title: "Complex Report Writing",
        description: "Structure and write detailed reports.",
        duration: "42 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Formal Debates",
        description: "Participate in structured debates with solid arguments.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Conference Comprehension",
        description: "Follow and understand technical conferences.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Legal Vocabulary",
        description: "Specialized terminology for the legal field.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Advanced Idiomatic Expressions",
        description: "Master the most complex expressions.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Intercultural Communication",
        description: "Adapt your communication to cultural differences.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Creative Writing",
        description: "Develop your personal writing style.",
        duration: "50 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Speech Analysis",
        description: "Analyze persuasion techniques in speeches.",
        duration: "42 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Scientific Vocabulary",
        description: "Specialized terms for scientific publications.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Complex Text Interpretation",
        description: "Decipher the most difficult texts.",
        duration: "45 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "Crisis Communication",
        description: "Manage communications in crisis situations.",
        duration: "35 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Linguistic Style and Elegance",
        description: "Refine your expression for more elegance.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Film and Series Analysis",
        description: "Decode cultural nuances in media.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Article Writing",
        description: "Structure and write professional articles.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Regional Dialects",
        description: "Understand regional variations of English.",
        duration: "42 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 21,
        title: "Non-Verbal Communication",
        description: "Master body language in English-speaking contexts.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 22,
        title: "Advanced Translation",
        description: "Techniques for translating complex texts.",
        duration: "50 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 23,
        title: "Rhetoric and Persuasion",
        description: "Use rhetorical techniques effectively.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 24,
        title: "Media English",
        description: "Understand and use journalistic language.",
        duration: "38 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 25,
        title: "Final Mastery",
        description: "Test your skills with ultimate challenges.",
        duration: "60 min",
        difficulty: "expert",
        completed: false,
        locked: true,
        progress: 0
    }
];

// DOM Elements
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialization
document.addEventListener('DOMContentLoaded', function() {
    console.log("Advanced page loaded!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Render lessons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Create a lesson card
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completed' : lesson.locked ? 'Locked' : 'In Progress';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'hard' ? 'difficulty-hard' : 'difficulty-expert';
    const difficultyText = lesson.difficulty === 'hard' ? 'Hard' : 'Expert';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Locked</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Review</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Redo</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continue' : 'Start'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Update global progress
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lessons completed`;
}

// Start a lesson
function startLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html`;
}

// Continue a lesson
function continueLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?continue=true`;
}

// Review a lesson
function reviewLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?review=true`;
}

// Set up event listeners
function setupEventListeners() {
    // Filters
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Get current filter
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Function to mark a lesson as completed (for testing)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Unlock the next lesson if it exists
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ Congratulations! You have completed the lesson "${lesson.title}"`);
    }
}

// Function to unlock all lessons (for testing)
function unlockAllLessons() {
    if (confirm("Do you want to unlock all lessons? (Test function)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("All lessons have been unlocked!");
    }
}

// Add these functions to the console for testing
console.log(`Available functions:
- completeLesson(lessonId) : Mark a lesson as completed
- unlockAllLessons() : Unlock all lessons
`);
// Modifiez l'initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Intermediate page loaded!");
    syncProgressWithLocalStorage();
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});