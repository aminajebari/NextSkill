import ReactCoursePlatform from "@/components/react-course-platform"

export default function ReactCoursePage() {
  return <ReactCoursePlatform />
}
