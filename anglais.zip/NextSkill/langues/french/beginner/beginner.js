// Données des leçons pour le niveau débutant français
const lessonsData = [
    {
        id: 1,
        title: "Salutations et présentations",
        description: "Apprenez à dire bonjour, au revoir et à vous présenter en français.",
        duration: "12 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "L'alphabet et la prononciation",
        description: "Maîtrisez l'alphabet français et les sons spécifiques.",
        duration: "18 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Les chiffres de 1 à 100",
        description: "Comptez jusqu'à 100 et utilisez les chiffres dans des phrases.",
        duration: "15 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Les articles et le genre",
        description: "Apprenez à utiliser les articles définis et indéfinis.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 40
    },
    {
        id: 5,
        title: "Le présent des verbes réguliers",
        description: "Conjuguez les verbes du premier groupe au présent.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 20
    },
    {
        id: 6,
        title: "La famille et les relations",
        description: "Vocabulaire pour parler de votre famille et entourage.",
        duration: "18 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Les couleurs et les formes",
        description: "Nommez et utilisez les couleurs et formes de base.",
        duration: "14 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "La nourriture et les boissons",
        description: "Vocabulaire essentiel pour commander et manger.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Les jours et les mois",
        description: "Apprenez à parler des dates et de la météo.",
        duration: "16 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Les nationalités et pays",
        description: "Exprimez votre origine et parlez des pays.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Poser des questions simples",
        description: "Formulez des questions courantes en français.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Les vêtements et accessoires",
        description: "Décrivez ce que vous portez et achetez des vêtements.",
        duration: "20 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "La maison et les pièces",
        description: "Vocabulaire pour décrire votre logement.",
        duration: "17 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Les professions et métiers",
        description: "Parlez de votre travail et des différents métiers.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Révision générale débutant",
        description: "Testez vos connaissances avec des exercices de synthèse.",
        duration: "30 min",
        difficulty: "medium",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Éléments DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Page Débutant Français chargée !");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendu des leçons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true;
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Création d'une carte de leçon
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Terminé' : lesson.locked ? 'Verrouillé' : 'En cours';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'easy' ? 'difficulty-easy' : 'difficulty-medium';
    const difficultyText = lesson.difficulty === 'easy' ? 'Facile' : 'Moyen';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Verrouillé</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Réviser</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Refaire</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continuer' : 'Commencer'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Mise à jour de la progression globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} leçons complétées`;
}

// Démarrer une leçon
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Démarrage de la leçon: ${lesson.title}`);
    
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuer une leçon
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Reprise de la leçon: ${lesson.title}`);
    renderLessons(getCurrentFilter());
}

// Réviser une leçon
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Révision de la leçon: ${lesson.title}`);
}

// Configuration des écouteurs d'événements
function setupEventListeners() {
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Obtenir le filtre actuel
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}