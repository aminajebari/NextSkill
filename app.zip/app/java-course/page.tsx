import JavaCoursePlatform from "@/components/java-course-platform"

export default function JavaCoursePage() {
  return <JavaCoursePlatform />
}
