// Données des leçons pour le niveau avancé français
const lessonsData = [
    {
        id: 1,
        title: "Le subjonctif passé et imparfait",
        description: "Maîtrisez les temps du subjonctif dans leur complexité.",
        duration: "35 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 2,
        title: "La littérature classique française",
        description: "Analysez les œuvres des grands auteurs classiques.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 3,
        title: "L'argumentation rhétorique",
        description: "Maîtrisez les techniques de persuasion avancées.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 4,
        title: "Les subtilités de la syntaxe",
        description: "Perfectionnez votre maîtrise de la structure de la phrase.",
        duration: "38 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 5,
        title: "Le français des affaires et du droit",
        description: "Vocabulaire et expressions du monde professionnel et juridique.",
        duration: "42 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 6,
        title: "L'analyse stylistique",
        description: "Apprenez à analyser le style et la langue d'un texte.",
        duration: "48 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Les régionalismes et dialectes",
        description: "Découvrez la richesse des variations régionales du français.",
        duration: "36 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "La poésie française",
        description: "Analysez les techniques poétiques et les grands mouvements.",
        duration: "44 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Le discours académique",
        description: "Maîtrisez le langage et les conventions du monde académique.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Les néologismes et l'évolution de la langue",
        description: "Comprenez comment le français évolue et s'enrichit.",
        duration: "38 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "La traduction littéraire",
        description: "Techniques avancées pour traduire des textes littéraires.",
        duration: "50 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "L'éloquence et l'art oratoire",
        description: "Perfectionnez votre expression orale dans des contextes formels.",
        duration: "42 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "La critique littéraire",
        description: "Apprenez à rédiger des analyses et critiques de textes.",
        duration: "46 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Le français de la diplomatie",
        description: "Langage et conventions du monde diplomatique.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Les jeux de mots et calembours",
        description: "Maîtrisez l'art du jeu de mots et de l'humour linguistique.",
        duration: "34 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "La rédaction créative",
        description: "Développez votre style personnel d'écriture.",
        duration: "48 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "L'histoire de la langue française",
        description: "Comprenez l'évolution du français à travers les siècles.",
        duration: "52 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Les particularités grammaticales avancées",
        description: "Approfondissez les points de grammaire les plus complexes.",
        duration: "44 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Le français des médias",
        description: "Analysez le langage journalistique et médiatique.",
        duration: "38 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Les courants philosophiques en français",
        description: "Découvrez le vocabulaire et les concepts philosophiques.",
        duration: "50 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 21,
        title: "L'analyse du discours politique",
        description: "Décryptez les techniques de communication politique.",
        duration: "42 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 22,
        title: "La linguistique française",
        description: "Initiation aux concepts fondamentaux de la linguistique.",
        duration: "46 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 23,
        title: "Le français de la publicité",
        description: "Analysez les stratégies langagières du monde publicitaire.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 24,
        title: "Les expressions littéraires rares",
        description: "Enrichissez votre vocabulaire avec des expressions peu courantes.",
        duration: "36 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 25,
        title: "Perfectionnement ultime",
        description: "Défis linguistiques pour tester votre maîtrise complète du français.",
        duration: "60 min",
        difficulty: "expert",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Éléments DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Page Avancé Français chargée !");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendu des leçons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true;
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Création d'une carte de leçon
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Terminé' : lesson.locked ? 'Verrouillé' : 'En cours';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'hard' ? 'difficulty-hard' : 'difficulty-expert';
    const difficultyText = lesson.difficulty === 'hard' ? 'Difficile' : 'Expert';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Verrouillé</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Réviser</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Refaire</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continuer' : 'Commencer'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Mise à jour de la progression globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} leçons complétées`;
}

// Démarrer une leçon
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Démarrage de la leçon: ${lesson.title}`);
    
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuer une leçon
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Reprise de la leçon: ${lesson.title}`);
    renderLessons(getCurrentFilter());
}

// Réviser une leçon
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Révision de la leçon: ${lesson.title}`);
}

// Configuration des écouteurs d'événements
function setupEventListeners() {
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Obtenir le filtre actuel
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}