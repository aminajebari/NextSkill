// Datos de las lecciones para el nivel intermedio
const lessonsData = [
    {
        id: 1,
        title: "Tiempos pasados - Parte 1",
        description: "Aprende a usar el pasado simple y el presente perfecto.",
        duration: "20 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Tiempos pasados - Parte 2",
        description: "Domina el pasado continuo y el pasado perfecto.",
        duration: "25 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Condicional y hipótesis",
        description: "Expresa condiciones e hipótesis en inglés.",
        duration: "22 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Phrasal verbs comunes",
        description: "Descubre los verbos compuestos más utilizados.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 40
    },
    {
        id: 5,
        title: "Conversaciones telefónicas",
        description: "Aprende a comunicarte efectivamente por teléfono.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 20
    },
    {
        id: 6,
        title: "Expresar tu opinión",
        description: "Técnicas para expresar tus opiniones claramente.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Describir experiencias",
        description: "Relata tus experiencias personales y profesionales.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Vocabulario de negocios",
        description: "Términos esenciales para el mundo profesional.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Comprensión auditiva avanzada",
        description: "Mejora tu escucha con diálogos complejos.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Discurso indirecto",
        description: "Aprende a reportar las palabras de alguien.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Escritura formal",
        description: "Redacta emails y cartas profesionales.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Modismos y expresiones",
        description: "Descubre las expresiones idiomáticas comunes.",
        duration: "25 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Pronunciación avanzada",
        description: "Perfecciona tu acento y entonación.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Conversaciones en contexto social",
        description: "Interactúa en diversas situaciones sociales.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Vocabulario técnico",
        description: "Términos especializados según tus intereses.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "Comprensión de textos complejos",
        description: "Analiza artículos y textos avanzados.",
        duration: "32 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Debates y discusiones",
        description: "Participa activamente en debates en inglés.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Cultura anglófona",
        description: "Descubre los matices culturales de los países anglófonos.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Preparación para entrevistas",
        description: "Prepárate para entrevistas en inglés.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Repaso general intermedio",
        description: "Pon a prueba tus conocimientos con ejercicios de síntesis.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Elementos DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    console.log("¡Página Intermedio cargada!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Renderizado de lecciones
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Creación de una tarjeta de lección
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completada' : lesson.locked ? 'Bloqueada' : 'En Progreso';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'medium' ? 'Medio' : 'Difícil';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Bloqueada</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Revisar</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Rehacer</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continuar' : 'Comenzar'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Actualización del progreso global
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lecciones completadas`;
}

// Comenzar una lección
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Comenzando lección: ${lesson.title}`);
    
    // Simulación de progreso
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuar una lección
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Continuando lección: ${lesson.title}\n\nEstás continuando al ${lesson.progress}% de progreso.`);
}

// Revisar una lección
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Revisando lección: ${lesson.title}\n\nEsta función te permite revisar contenido ya aprendido.`);
}

// Configuración de event listeners
function setupEventListeners() {
    // Filtros
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Obtener el filtro actual
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Función para marcar una lección como completada (para pruebas)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Desbloquear la siguiente lección si existe
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ ¡Felicidades! Has completado la lección "${lesson.title}"`);
    }
}

// Función para desbloquear todas las lecciones (para pruebas)
function unlockAllLessons() {
    if (confirm("¿Quieres desbloquear todas las lecciones? (Función de prueba)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("¡Todas las lecciones han sido desbloqueadas!");
    }
}

// Añadir estas funciones a la consola para pruebas
console.log(`Funciones disponibles:
- completeLesson(lessonId) : Marcar una lección como completada
- unlockAllLessons() : Desbloquear todas las lecciones
`);