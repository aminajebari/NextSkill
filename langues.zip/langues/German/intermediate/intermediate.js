// Données des leçons pour le niveau intermédiaire - Allemand
const lessonsData = [
    {
        id: 1,
        title: "Perfekt und Präteritum",
        description: "Meistern Sie die Vergangenheitsformen im Deutschen.",
        duration: "25 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Dativ und Akkusativ",
        description: "Verstehen und verwenden Sie die deutschen Fälle korrekt.",
        duration: "30 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Modalverben",
        description: "Lernen Sie können, müssen, wollen und andere Modalverben.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 60
    },
    {
        id: 4,
        title: "Trennbare Verben",
        description: "Verstehen Sie die Besonderheiten trennbarer Verben.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 5,
        title: "Adjektivdeklination",
        description: "Lernen Sie, Adjektive korrekt zu deklinieren.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 6,
        title: "Nebensätze mit dass",
        description: "Bilden Sie komplexere Sätze mit Nebensätzen.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Weil, denn, da",
        description: "Unterschiedliche Konjunktionen für Begründungen.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Relativsätze",
        description: "Erweitern Sie Ihre Sätze mit Relativpronomen.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Indirekte Fragen",
        description: "Formulieren Sie Fragen in indirekter Rede.",
        duration: "15 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Wortbildung",
        description: "Verstehen Sie Präfixe, Suffixe und Komposita.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Beruf und Arbeit",
        description: "Fachvokabular für den Arbeitskontext.",
        duration: "30 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Deutsche Kultur und Bräuche",
        description: "Interkulturelles Wissen für bessere Kommunikation.",
        duration: "35 min",
        difficulty: "medium",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Éléments DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Seite Mittelstufe geladen!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendu des leçons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Création d'une carte de leçon
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Abgeschlossen' : lesson.locked ? 'Gesperrt' : 'In Bearbeitung';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'easy' ? 'difficulty-easy' : lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'easy' ? 'Einfach' : lesson.difficulty === 'medium' ? 'Mittel' : 'Schwer';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Gesperrt</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Wiederholen</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Nochmal machen</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Fortsetzen' : 'Starten'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Mise à jour de la progression globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} Lektionen abgeschlossen`;
}

// Démarrer une leçon
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Start der Lektion: ${lesson.title}\n\nDiese Funktion öffnet die Lernoberfläche in einer vollständigen Version.`);
    
    // Simulation de progression
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuer une leçon
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Fortsetzung der Lektion: ${lesson.title}\n\nSie setzen fort bei ${lesson.progress}% Fortschritt.`);
}

// Réviser une leçon
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Wiederholung der Lektion: ${lesson.title}\n\nDiese Funktion ermöglicht es Ihnen, bereits gelernte Inhalte zu überprüfen.`);
}

// Marquer une leçon comme complétée (pour test)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Déverrouiller la leçon suivante si elle existe
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        // Animation de félicitations
        if (lessonId === lessonsData.length) {
            alert('🎉 Herzlichen Glückwunsch! Sie haben alle Lektionen der Mittelstufe abgeschlossen! 🎉');
        } else {
            alert(`✅ Herzlichen Glückwunsch! Sie haben die Lektion "${lesson.title}" abgeschlossen`);
        }
    }
}

// Configuration des écouteurs d'événements
function setupEventListeners() {
    // Filtres
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Mettre à jour les boutons actifs
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Appliquer le filtre
            renderLessons(filter);
        });
    });
}

// Obtenir le filtre actuel
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Fonction de déverrouillage de toutes les leçons (pour test)
function unlockAllLessons() {
    if (confirm("Möchten Sie alle Lektionen entsperren? (Testfunktion)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("Alle Lektionen wurden entsperrt!");
    }
}

// Fonction de réinitialisation (pour test)
function resetProgress() {
    if (confirm("Möchten Sie Ihren gesamten Fortschritt zurücksetzen?")) {
        lessonsData.forEach((lesson, index) => {
            lesson.completed = index < 2; // Garder les 2 premières complétées pour l'exemple
            lesson.progress = lesson.completed ? 100 : 0;
            lesson.locked = index >= 11; // Verrouiller la dernière leçon
        });
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        alert("Fortschritt zurückgesetzt!");
    }
}

// Ajouter ces fonctions à la console pour test
console.log(`Verfügbare Funktionen:
- completeLesson(lessonId) : Lektion als abgeschlossen markieren
- unlockAllLessons() : Alle Lektionen entsperren
- resetProgress() : Fortschritt zurücksetzen
`);