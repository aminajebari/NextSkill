// Lessons data for intermediate level
const lessonsData = [
    {
        id: 1,
        title: "Past Tenses - Part 1",
        description: "Learn to use the simple past and present perfect.",
        duration: "20 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Past Tenses - Part 2",
        description: "Master the past continuous and past perfect.",
        duration: "25 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Conditional and Hypotheses",
        description: "Express conditions and hypotheses in English.",
        duration: "22 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Common Phrasal Verbs",
        description: "Discover the most used particle verbs.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 40
    },
    {
        id: 5,
        title: "Phone Conversations",
        description: "Learn to communicate effectively on the phone.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 20
    },
    {
        id: 6,
        title: "Expressing Your Opinion",
        description: "Techniques to express your opinions clearly.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Describing Experiences",
        description: "Talk about your personal and professional experiences.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Business Vocabulary",
        description: "Essential terms for the professional world.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Advanced Listening Comprehension",
        description: "Improve your listening with complex dialogues.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Reported Speech",
        description: "Learn to report someone's words.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Formal Writing",
        description: "Write professional emails and letters.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Idioms and Expressions",
        description: "Discover common idiomatic expressions.",
        duration: "25 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Advanced Pronunciation",
        description: "Perfect your accent and intonation.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Social Context Conversations",
        description: "Interact in various social situations.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Technical Vocabulary",
        description: "Specialized terms according to your interests.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "Complex Text Comprehension",
        description: "Analyze articles and advanced texts.",
        duration: "32 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Debates and Discussions",
        description: "Participate actively in English debates.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "English-speaking Culture",
        description: "Discover cultural nuances of English-speaking countries.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Interview Preparation",
        description: "Prepare for interviews in English.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Intermediate General Review",
        description: "Test your knowledge with synthesis exercises.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: true,
        progress: 0
    }
];

// DOM Elements
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialization
document.addEventListener('DOMContentLoaded', function() {
    console.log("Intermediate page loaded!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Render lessons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Create a lesson card
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completed' : lesson.locked ? 'Locked' : 'In Progress';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'medium' ? 'Medium' : 'Hard';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Locked</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Review</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Redo</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continue' : 'Start'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Update global progress
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lessons completed`;
}

// Start a lesson
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Starting lesson: ${lesson.title}`);
    
    // Progress simulation
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Start a lesson
function startLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html`;
}

// Continue a lesson
function continueLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?continue=true`;
}

// Review a lesson
function reviewLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?review=true`;
}

// Setup event listeners
function setupEventListeners() {
    // Filters
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Get current filter
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Function to mark a lesson as completed (for testing)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Unlock the next lesson if it exists
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ Congratulations! You have completed the lesson "${lesson.title}"`);
    }
}

// Function to unlock all lessons (for testing)
function unlockAllLessons() {
    if (confirm("Do you want to unlock all lessons? (Test function)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("All lessons have been unlocked!");
    }
}

// Add these functions to the console for testing
console.log(`Available functions:
- completeLesson(lessonId) : Mark a lesson as completed
- unlockAllLessons() : Unlock all lessons
`);
// Ajoutez cette fonction pour synchroniser la progression
function syncProgressWithLocalStorage() {
    lessonsData.forEach(lesson => {
        const completed = localStorage.getItem(`intermediate-lesson${lesson.id}-completed`);
        const progress = localStorage.getItem(`intermediate-lesson${lesson.id}-progress`);
        
        if (completed === 'true') {
            lesson.completed = true;
            lesson.progress = 100;
        } else if (progress) {
            lesson.progress = parseInt(progress);
        }
    });
}

// Modifiez l'initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Intermediate page loaded!");
    syncProgressWithLocalStorage();
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});