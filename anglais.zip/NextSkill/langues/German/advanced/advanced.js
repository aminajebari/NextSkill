// Lektionsdaten für das fortgeschrittene Niveau
const lessonsData = [
    {
        id: 1,
        title: "Akademisches Schreiben",
        description: "Beherrschen Sie formelles Schreiben für akademische Veröffentlichungen.",
        duration: "40 min",
        difficulty: "expert",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Komplexe Verhandlungen",
        description: "Fortgeschrittene Techniken für Geschäftsverhandlungen.",
        duration: "35 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 3,
        title: "Executive-Präsentationen",
        description: "Präsentieren Sie effektiv vor anspruchsvollem Publikum.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 4,
        title: "Literarische Analyse",
        description: "Analysieren Sie literarische Werke auf Englisch.",
        duration: "50 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 5,
        title: "Diplomatische Sprache",
        description: "Kommunizieren Sie präzise in diplomatischen Kontexten.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 6,
        title: "Komplexe Berichterstellung",
        description: "Strukturieren und verfassen Sie detaillierte Berichte.",
        duration: "42 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Formelle Debatten",
        description: "Nehmen Sie an strukturierten Debatten mit soliden Argumenten teil.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Konferenzverständnis",
        description: "Folgen und verstehen Sie technischen Konferenzen.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Juristischer Wortschatz",
        description: "Fachspezifische Terminologie für den Rechtsbereich.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Fortgeschrittene idiomatische Ausdrücke",
        description: "Beherrschen Sie die komplexesten Ausdrücke.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Interkulturelle Kommunikation",
        description: "Passen Sie Ihre Kommunikation an kulturelle Unterschiede an.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Kreatives Schreiben",
        description: "Entwickeln Sie Ihren persönlichen Schreibstil.",
        duration: "50 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Redeanalyse",
        description: "Analysieren Sie Überzeugungstechniken in Reden.",
        duration: "42 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Wissenschaftlicher Wortschatz",
        description: "Fachspezifische Begriffe für wissenschaftliche Veröffentlichungen.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Interpretation komplexer Texte",
        description: "Entschlüsseln Sie die schwierigsten Texte.",
        duration: "45 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "Krisenkommunikation",
        description: "Verwalten Sie Kommunikation in Krisensituationen.",
        duration: "35 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Sprachlicher Stil und Eleganz",
        description: "Verfeinern Sie Ihren Ausdruck für mehr Eleganz.",
        duration: "38 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Film- und Serienanalyse",
        description: "Entschlüsseln Sie kulturelle Nuancen in Medien.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "Artikelerstellung",
        description: "Strukturieren und verfassen Sie professionelle Artikel.",
        duration: "45 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Regionale Dialekte",
        description: "Verstehen Sie regionale Variationen des Englischen.",
        duration: "42 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 21,
        title: "Nonverbale Kommunikation",
        description: "Beherrschen Sie die Körpersprache in englischsprachigen Kontexten.",
        duration: "35 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 22,
        title: "Fortgeschrittene Übersetzung",
        description: "Techniken zum Übersetzen komplexer Texte.",
        duration: "50 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 23,
        title: "Rhetorik und Überzeugung",
        description: "Verwenden Sie rhetorische Techniken effektiv.",
        duration: "40 min",
        difficulty: "expert",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 24,
        title: "Medienenglisch",
        description: "Verstehen und verwenden Sie journalistische Sprache.",
        duration: "38 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 25,
        title: "Finale Meisterschaft",
        description: "Testen Sie Ihre Fähigkeiten mit ultimativen Herausforderungen.",
        duration: "60 min",
        difficulty: "expert",
        completed: false,
        locked: true,
        progress: 0
    }
];

// DOM-Elemente
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialisierung
document.addEventListener('DOMContentLoaded', function() {
    console.log("Fortgeschrittene Seite geladen!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Lektionen rendern
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Lektionskarte erstellen
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Abgeschlossen' : lesson.locked ? 'Gesperrt' : 'In Bearbeitung';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'hard' ? 'difficulty-hard' : 'difficulty-expert';
    const difficultyText = lesson.difficulty === 'hard' ? 'Schwer' : 'Experte';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Gesperrt</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Wiederholen</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Erneut machen</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Fortsetzen' : 'Starten'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Globalen Fortschritt aktualisieren
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} Lektionen abgeschlossen`;
}

// Lektion starten
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Lektion starten: ${lesson.title}`);
    
    // Fortschrittssimulation
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Lektion fortsetzen
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Lektion fortsetzen: ${lesson.title}\n\nSie setzen bei ${lesson.progress}% Fortschritt fort.`);
}

// Lektion wiederholen
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Lektion wiederholen: ${lesson.title}\n\nDiese Funktion ermöglicht es Ihnen, bereits gelernte Inhalte zu wiederholen.`);
}

// Event-Listener einrichten
function setupEventListeners() {
    // Filter
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Aktuellen Filter abrufen
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Funktion zum Markieren einer Lektion als abgeschlossen (für Tests)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Nächste Lektion entsperren, falls vorhanden
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ Herzlichen Glückwunsch! Sie haben die Lektion "${lesson.title}" abgeschlossen`);
    }
}

// Funktion zum Entsperren aller Lektionen (für Tests)
function unlockAllLessons() {
    if (confirm("Möchten Sie alle Lektionen entsperren? (Testfunktion)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("Alle Lektionen wurden entsperrt!");
    }
}

// Diese Funktionen für Tests der Konsole hinzufügen
console.log(`Verfügbare Funktionen:
- completeLesson(lessonId) : Lektion als abgeschlossen markieren
- unlockAllLessons() : Alle Lektionen entsperren
`);