import HTMLCoursePlatform from "@/components/html-course-platform"

export default function HTMLCoursePage() {
  return <HTMLCoursePlatform />
}
