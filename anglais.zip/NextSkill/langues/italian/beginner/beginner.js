// Dati delle lezioni per il livello principiante
const lessonsData = [
    {
        id: 1,
        title: "Alfabeto e pronuncia",
        description: "Impara l'alfabeto inglese e la corretta pronuncia.",
        duration: "15 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Saluti e presentazioni",
        description: "Come salutare e presentarsi in inglese.",
        duration: "20 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Numeri e colori",
        description: "Impara i numeri da 1 a 100 e i colori principali.",
        duration: "18 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Articoli e plurali",
        description: "Uso corretto di 'a', 'an', 'the' e formazione dei plurali.",
        duration: "22 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 60
    },
    {
        id: 5,
        title: "Verbo 'to be'",
        description: "Coniugazione e uso del verbo essere.",
        duration: "25 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 6,
        title: "Pronomi personali",
        description: "I, you, he, she, it, we, they - uso corretto.",
        duration: "20 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Presente semplice",
        description: "Formazione e uso del present simple.",
        duration: "28 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Vocabolario: famiglia",
        description: "Termini per descrivere la famiglia e le relazioni.",
        duration: "18 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Preposizioni di luogo",
        description: "In, on, at, under, next to - uso corretto.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Aggettivi possessivi",
        description: "My, your, his, her, its, our, their.",
        duration: "20 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Domande con 'do/does'",
        description: "Come formulare domande al presente semplice.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Vocabolario: cibo e bevande",
        description: "Termini per ordinare al ristorante e fare la spesa.",
        duration: "22 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Avverbi di frequenza",
        description: "Always, often, sometimes, never - posizione e uso.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "There is / There are",
        description: "Esprimere esistenza e quantità.",
        duration: "18 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Ripasso generale",
        description: "Esercizi di sintesi per consolidare le conoscenze.",
        duration: "30 min",
        difficulty: "medium",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Elementi DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Inizializzazione
document.addEventListener('DOMContentLoaded', function() {
    console.log("Pagina Principiante caricata!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendering delle lezioni
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Creazione di una carta lezione
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completata' : lesson.locked ? 'Bloccata' : 'In Corso';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'easy' ? 'difficulty-easy' : lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'easy' ? 'Facile' : lesson.difficulty === 'medium' ? 'Medio' : 'Difficile';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Bloccata</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Rivedi</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Rifai</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continua' : 'Inizia'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Aggiornamento del progresso globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lezioni completate`;
}

// Iniziare una lezione
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Inizio lezione: ${lesson.title}`);
    
    // Simulazione del progresso
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuare una lezione
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Ripresa lezione: ${lesson.title}\n\nStai continuando al ${lesson.progress}% di progresso.`);
}

// Rivedere una lezione
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Revisione lezione: ${lesson.title}\n\nQuesta funzione ti permette di rivedere i contenuti già appresi.`);
}

// Configurazione degli event listener
function setupEventListeners() {
    // Filtri
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Ottenere il filtro corrente
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Funzione per segnare una lezione come completata (per test)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Sbloccare la lezione successiva se esiste
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        alert(`✅ Congratulazioni! Hai completato la lezione "${lesson.title}"`);
    }
}

// Funzione per sbloccare tutte le lezioni (per test)
function unlockAllLessons() {
    if (confirm("Vuoi sbloccare tutte le lezioni? (Funzione di test)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("Tutte le lezioni sono state sbloccate!");
    }
}

// Aggiungere queste funzioni alla console per i test
console.log(`Funzioni disponibili:
- completeLesson(lessonId) : Segna una lezione come completata
- unlockAllLessons() : Sblocca tutte le lezioni
`);