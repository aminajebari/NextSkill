'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Navigation from "@/components/navigation"
import Footer from "@/components/footer"
import { Clock, Users, BookOpen, Star, Search } from 'lucide-react'
import Link from 'next/link'

// Course data structure
const coursesData = {
  english: [
    { id: 1, title: "English Grammar Fundamentals", level: "A2", duration: "6 weeks", students: 1234, rating: 4.8, description: "Master basic English grammar and sentence structure" },
    { id: 2, title: "English Conversation Practice", level: "B1", duration: "8 weeks", students: 987, rating: 4.7, description: "Improve your speaking and listening skills" },
    { id: 3, title: "Advanced English Writing", level: "B2", duration: "10 weeks", students: 756, rating: 4.9, description: "Professional writing and communication skills" },
    { id: 4, title: "English for Business", level: "C1", duration: "12 weeks", students: 543, rating: 4.8, description: "Master business English and professional communication" },
  ],
  french: [
    { id: 5, title: "French for Beginners", level: "A2", duration: "6 weeks", students: 892, rating: 4.6, description: "Start your French learning journey" },
    { id: 6, title: "Intermediate French", level: "B1", duration: "8 weeks", students: 654, rating: 4.7, description: "Build on your French foundation" },
    { id: 7, title: "Advanced French Conversation", level: "B2", duration: "10 weeks", students: 432, rating: 4.8, description: "Speak French fluently and confidently" },
    { id: 8, title: "French Literature and Culture", level: "C1", duration: "12 weeks", students: 321, rating: 4.9, description: "Deep dive into French culture and literature" },
  ],
  italian: [
    { id: 9, title: "Italian Basics", level: "A2", duration: "6 weeks", students: 765, rating: 4.7, description: "Learn essential Italian phrases and grammar" },
    { id: 10, title: "Conversational Italian", level: "B1", duration: "8 weeks", students: 543, rating: 4.6, description: "Practice everyday Italian conversations" },
    { id: 11, title: "Italian for Travel", level: "B2", duration: "10 weeks", students: 432, rating: 4.8, description: "Navigate Italy like a local" },
    { id: 12, title: "Advanced Italian", level: "C1", duration: "12 weeks", students: 234, rating: 4.9, description: "Master complex Italian grammar and expressions" },
  ],
  spanish: [
    { id: 13, title: "Spanish Fundamentals", level: "A2", duration: "6 weeks", students: 1432, rating: 4.8, description: "Start learning Spanish from scratch" },
    { id: 14, title: "Spanish Conversation", level: "B1", duration: "8 weeks", students: 1098, rating: 4.7, description: "Improve your Spanish speaking skills" },
    { id: 15, title: "Advanced Spanish Grammar", level: "B2", duration: "10 weeks", students: 876, rating: 4.9, description: "Master complex Spanish structures" },
    { id: 16, title: "Spanish for Professionals", level: "C1", duration: "12 weeks", students: 543, rating: 4.8, description: "Business Spanish and professional communication" },
  ],
  html: [
    { id: 17, title: "HTML Basics", level: "Beginner", duration: "4 weeks", students: 2345, rating: 4.9, description: "Learn the fundamentals of HTML" },
    { id: 18, title: "HTML & CSS Integration", level: "Intermediate", duration: "6 weeks", students: 1876, rating: 4.8, description: "Build beautiful web pages" },
    { id: 19, title: "Advanced HTML5", level: "Master", duration: "8 weeks", students: 987, rating: 4.9, description: "Master modern HTML5 features" },
  ],
  css: [
    { id: 20, title: "CSS Basics", level: "Beginner", duration: "4 weeks", students: 1567, rating: 4.8, description: "Learn the fundamentals of CSS" },
    { id: 21, title: "CSS Flexbox and Grid", level: "Intermediate", duration: "6 weeks", students: 1234, rating: 4.9, description: "Master layout techniques with Flexbox and Grid" },
    { id: 22, title: "Advanced CSS Animations", level: "Master", duration: "8 weeks", students: 876, rating: 4.9, description: "Create stunning animations with CSS" },
  ],
  cpp: [
    { id: 23, title: "C++ Programming Basics", level: "Beginner", duration: "8 weeks", students: 1654, rating: 4.7, description: "Introduction to C++ programming" },
    { id: 24, title: "Object-Oriented C++", level: "Intermediate", duration: "10 weeks", students: 1234, rating: 4.8, description: "Master OOP concepts in C++" },
    { id: 25, title: "Advanced C++ and STL", level: "Master", duration: "12 weeks", students: 765, rating: 4.9, description: "Advanced C++ techniques and Standard Template Library" },
  ],
  java: [
    { id: 26, title: "Java Fundamentals", level: "Beginner", duration: "8 weeks", students: 2987, rating: 4.8, description: "Start your Java programming journey" },
    { id: 27, title: "Java Object-Oriented Programming", level: "Intermediate", duration: "10 weeks", students: 2345, rating: 4.9, description: "Master Java OOP principles" },
    { id: 28, title: "Advanced Java Development", level: "Master", duration: "12 weeks", students: 1543, rating: 4.9, description: "Enterprise Java and advanced frameworks" },
  ],
  csharp: [
    { id: 29, title: "C# Programming Basics", level: "Beginner", duration: "8 weeks", students: 1876, rating: 4.7, description: "Learn C# from scratch" },
    { id: 30, title: "C# and .NET Framework", level: "Intermediate", duration: "10 weeks", students: 1432, rating: 4.8, description: "Build applications with .NET" },
    { id: 31, title: "Advanced C# Development", level: "Master", duration: "12 weeks", students: 987, rating: 4.9, description: "Master C# and enterprise development" },
  ],
  python: [
    { id: 32, title: "Python Fundamentals", level: "Beginner", duration: "8 weeks", students: 3456, rating: 4.9, description: "Learn Python from scratch" },
    { id: 33, title: "Python Data Structures", level: "Intermediate", duration: "10 weeks", students: 2543, rating: 4.8, description: "Master Python data structures" },
    { id: 34, title: "Advanced Python Programming", level: "Master", duration: "12 weeks", students: 1876, rating: 4.9, description: "Expert-level Python techniques" },
  ],
  react: [
    { id: 35, title: "React Fundamentals", level: "Beginner", duration: "8 weeks", students: 4123, rating: 4.9, description: "Learn React from scratch" },
    { id: 36, title: "Advanced React Patterns", level: "Intermediate", duration: "10 weeks", students: 3245, rating: 4.8, description: "Master React hooks and patterns" },
    { id: 37, title: "React Performance & Optimization", level: "Master", duration: "12 weeks", students: 2134, rating: 4.9, description: "Expert-level React development" },
  ],
}

function CoursesContent() {
  const searchParams = useSearchParams()
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    const category = searchParams.get('category')
    if (category) {
      setSelectedCategory(category)
    }
  }, [searchParams])

  const categories = [
    { id: 'all', name: 'All Courses' },
    { id: 'english', name: 'English' },
    { id: 'french', name: 'French' },
    { id: 'italian', name: 'Italian' },
    { id: 'spanish', name: 'Spanish' },
    { id: 'html', name: 'HTML' },
    { id: 'css', name: 'CSS' },
    { id: 'cpp', name: 'C++' },
    { id: 'java', name: 'Java' },
    { id: 'csharp', name: 'C#' },
    { id: 'python', name: 'Python' },
    { id: 'react', name: 'React' },
  ]

  const getAllCourses = () => {
    return Object.values(coursesData).flat()
  }

  const getFilteredCourses = () => {
    let courses = selectedCategory === 'all' ? getAllCourses() : coursesData[selectedCategory as keyof typeof coursesData] || []
    
    if (searchTerm) {
      courses = courses.filter(course => 
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    return courses
  }

  const filteredCourses = getFilteredCourses()

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary/10 via-secondary/5 to-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-5xl font-bold text-foreground mb-4 text-balance">Explore Our Courses</h1>
          <p className="text-xl text-muted-foreground max-w-2xl text-balance">
            Master languages and programming skills with expert-led courses
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
            <input
              type="text"
              placeholder="Search courses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-secondary text-white'
                    : 'bg-white border border-border text-slate-700 hover:border-secondary'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Courses Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => (
            <div key={course.id} className="bg-white border border-border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <BookOpen className="text-primary" size={64} />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-white bg-secondary px-3 py-1 rounded-full">
                    {course.level}
                  </span>
                  <div className="flex items-center gap-1">
                    <Star className="text-yellow-500 fill-yellow-500" size={16} />
                    <span className="text-sm font-medium">{course.rating}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{course.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">{course.description}</p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users size={16} />
                    <span>{course.students}</span>
                  </div>
                </div>
                <Link
                  href="/auth/signin"
                  className="block w-full text-center bg-primary text-white py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
                >
                  Enroll Now
                </Link>
              </div>
            </div>
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-16">
            <BookOpen className="mx-auto text-muted-foreground mb-4" size={64} />
            <h3 className="text-xl font-semibold text-foreground mb-2">No courses found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filter</p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

export default function CoursesPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <CoursesContent />
    </Suspense>
  )
}
