// Données des leçons pour le niveau intermédiaire français
const lessonsData = [
    {
        id: 1,
        title: "Les temps du passé",
        description: "Maîtrisez l'imparfait, le passé composé et le plus-que-parfait.",
        duration: "25 min",
        difficulty: "medium",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Le subjonctif présent",
        description: "Apprenez à utiliser le subjonctif dans différentes situations.",
        duration: "30 min",
        difficulty: "hard",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Les pronoms relatifs composés",
        description: "Utilisez correctement lequel, laquelle, lesquels, etc.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 40
    },
    {
        id: 4,
        title: "Le discours rapporté",
        description: "Apprenez à rapporter les paroles de quelqu'un.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 20
    },
    {
        id: 5,
        title: "Les expressions idiomatiques",
        description: "Découvrez les expressions courantes de la langue française.",
        duration: "24 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 6,
        title: "La voix passive",
        description: "Maîtrisez la construction et l'utilisation de la voix passive.",
        duration: "26 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 7,
        title: "Les connecteurs logiques",
        description: "Utilisez les mots de liaison pour structurer vos discours.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 8,
        title: "Le conditionnel présent et passé",
        description: "Exprimez des hypothèses et des souhaits.",
        duration: "32 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Les prépositions complexes",
        description: "Maîtrisez l'usage des prépositions dans différents contextes.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Le participe présent et gérondif",
        description: "Différenciez et utilisez correctement ces deux formes.",
        duration: "24 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Les registres de langue",
        description: "Adaptez votre langage selon le contexte et l'interlocuteur.",
        duration: "26 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "La négation complexe",
        description: "Utilisez les différentes formes de négation en français.",
        duration: "22 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "Les verbes pronominaux",
        description: "Maîtrisez l'accord des verbes pronominaux aux différents temps.",
        duration: "30 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "L'expression de l'hypothèse",
        description: "Exprimez différentes nuances d'hypothèses en français.",
        duration: "28 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "Les figures de style",
        description: "Découvrez et utilisez les principales figures de style.",
        duration: "32 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 16,
        title: "La concordance des temps",
        description: "Maîtrisez l'accord des temps dans les phrases complexes.",
        duration: "34 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 17,
        title: "Le vocabulaire abstrait",
        description: "Enrichissez votre vocabulaire avec des termes abstraits.",
        duration: "26 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 18,
        title: "Les nuances de sens",
        description: "Différenciez les mots de sens proches mais distincts.",
        duration: "28 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 19,
        title: "La rédaction argumentée",
        description: "Structurez et rédigez un texte argumentatif cohérent.",
        duration: "40 min",
        difficulty: "hard",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 20,
        title: "Révision générale intermédiaire",
        description: "Testez vos connaissances avec des exercices de synthèse.",
        duration: "45 min",
        difficulty: "hard",
        completed: false,
        locked: true,
        progress: 0
    }
];

// Éléments DOM
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Page Intermédiaire Français chargée !");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Rendu des leçons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true;
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Création d'une carte de leçon
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Terminé' : lesson.locked ? 'Verrouillé' : 'En cours';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'medium' ? 'difficulty-medium' : 'difficulty-hard';
    const difficultyText = lesson.difficulty === 'medium' ? 'Moyen' : 'Difficile';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Verrouillé</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Réviser</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Refaire</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continuer' : 'Commencer'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Mise à jour de la progression globale
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} leçons complétées`;
}

// Démarrer une leçon
function startLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Démarrage de la leçon: ${lesson.title}`);
    
    if (lesson.progress === 0) {
        lesson.progress = 10;
    }
    
    renderLessons(getCurrentFilter());
}

// Continuer une leçon
function continueLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Reprise de la leçon: ${lesson.title}`);
    renderLessons(getCurrentFilter());
}

// Réviser une leçon
function reviewLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (!lesson) return;
    
    alert(`Révision de la leçon: ${lesson.title}`);
}

// Configuration des écouteurs d'événements
function setupEventListeners() {
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            renderLessons(filter);
        });
    });
}

// Obtenir le filtre actuel
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}