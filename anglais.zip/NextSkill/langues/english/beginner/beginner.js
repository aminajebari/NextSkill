// Lessons data for beginner level
const lessonsData = [
    {
        id: 1,
        title: "Basic Greetings",
        description: "Learn how to say hello, goodbye and introduce yourself in English.",
        duration: "10 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 2,
        title: "Alphabet and Pronunciation",
        description: "Master the English alphabet and basic sounds.",
        duration: "15 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 3,
        title: "Numbers 1 to 20",
        description: "Count up to 20 and use numbers in simple sentences.",
        duration: "12 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 4,
        title: "Colors",
        description: "Name and use basic colors in English.",
        duration: "10 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 5,
        title: "Animals",
        description: "Discover vocabulary for common animals.",
        duration: "15 min",
        difficulty: "easy",
        completed: true,
        locked: false,
        progress: 100
    },
    {
        id: 6,
        title: "Family",
        description: "Learn to talk about family members.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 60
    },
    {
        id: 7,
        title: "Food and Drinks",
        description: "Essential vocabulary for ordering at restaurants.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 30
    },
    {
        id: 8,
        title: "Days of the Week",
        description: "Learn the days and talk about your routine.",
        duration: "12 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 9,
        title: "Months and Seasons",
        description: "Talk about dates and periods of the year.",
        duration: "15 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 10,
        title: "Present Simple",
        description: "Master the basics of English conjugation.",
        duration: "25 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 11,
        title: "Asking Simple Questions",
        description: "Learn to formulate common questions.",
        duration: "18 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 12,
        title: "Clothing",
        description: "Vocabulary to describe what you wear.",
        duration: "16 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 13,
        title: "House and Rooms",
        description: "Describe your daily environment.",
        duration: "14 min",
        difficulty: "easy",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 14,
        title: "Professions",
        description: "Learn to talk about jobs and professions.",
        duration: "20 min",
        difficulty: "medium",
        completed: false,
        locked: false,
        progress: 0
    },
    {
        id: 15,
        title: "General Review",
        description: "Test your knowledge with a synthesis exercise.",
        duration: "30 min",
        difficulty: "medium",
        completed: false,
        locked: true,
        progress: 0
    }
];

// DOM Elements
const lessonsGrid = document.getElementById('lessons-grid');
const globalProgressBar = document.getElementById('global-progress-bar');
const globalProgressText = document.getElementById('global-progress');
const lessonsCompletedText = document.getElementById('lessons-completed');
const filterButtons = document.querySelectorAll('.filter-btn');

// Initialization
document.addEventListener('DOMContentLoaded', function() {
    console.log("Beginner page loaded!");
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});

// Render lessons
function renderLessons(filter = 'all') {
    lessonsGrid.innerHTML = '';
    
    const filteredLessons = lessonsData.filter(lesson => {
        if (filter === 'completed') return lesson.completed;
        if (filter === 'pending') return !lesson.completed && !lesson.locked;
        return true; // 'all'
    });
    
    filteredLessons.forEach(lesson => {
        const lessonCard = createLessonCard(lesson);
        lessonsGrid.appendChild(lessonCard);
    });
}

// Create a lesson card
function createLessonCard(lesson) {
    const card = document.createElement('div');
    card.className = `lesson-card ${lesson.completed ? 'completed' : lesson.locked ? 'locked' : 'in-progress'}`;
    
    const statusText = lesson.completed ? 'Completed' : lesson.locked ? 'Locked' : 'In Progress';
    const statusClass = lesson.completed ? 'status-completed' : lesson.locked ? 'status-locked' : 'status-in-progress';
    const difficultyClass = lesson.difficulty === 'easy' ? 'difficulty-easy' : 'difficulty-medium';
    const difficultyText = lesson.difficulty === 'easy' ? 'Easy' : 'Medium';
    
    card.innerHTML = `
        ${lesson.progress > 0 && !lesson.completed ? `<div class="lesson-progress">${lesson.progress}%</div>` : ''}
        
        <div class="lesson-header">
            <div class="lesson-number">${lesson.id}</div>
            <div class="lesson-status ${statusClass}">${statusText}</div>
        </div>
        
        <div class="lesson-content">
            <h3>${lesson.title}</h3>
            <p class="lesson-description">${lesson.description}</p>
            
            <div class="lesson-meta">
                <div class="lesson-duration">
                    <span>⏱️ ${lesson.duration}</span>
                </div>
                <div class="lesson-difficulty ${difficultyClass}">
                    ${difficultyText}
                </div>
            </div>
            
            <div class="lesson-actions">
                ${lesson.locked ? 
                    `<button class="btn-lesson btn-disabled" disabled>Locked</button>` :
                    lesson.completed ?
                    `<button class="btn-lesson btn-secondary" onclick="reviewLesson(${lesson.id})">Review</button>
                     <button class="btn-lesson btn-primary" onclick="continueLesson(${lesson.id})">Redo</button>` :
                    `<button class="btn-lesson btn-primary" onclick="startLesson(${lesson.id})">${lesson.progress > 0 ? 'Continue' : 'Start'}</button>`
                }
            </div>
        </div>
    `;
    
    return card;
}

// Update global progress
function updateGlobalProgress() {
    const completedLessons = lessonsData.filter(lesson => lesson.completed).length;
    const totalLessons = lessonsData.length;
    const progress = Math.round((completedLessons / totalLessons) * 100);
    
    globalProgressBar.style.width = `${progress}%`;
    globalProgressText.textContent = `${progress}%`;
    lessonsCompletedText.textContent = `${completedLessons}/${totalLessons} lessons completed`;
}

// Start a lesson
function startLesson(lessonId) {
    // Redirige vers le fichier de leçon correspondant
    window.location.href = `lessons/lesson${lessonId}.html`;
}

// Continue a lesson
function continueLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?continue=true`;
}

// Review a lesson
function reviewLesson(lessonId) {
    window.location.href = `lessons/lesson${lessonId}.html?review=true`;
}

// Mark a lesson as completed (for testing)
function completeLesson(lessonId) {
    const lesson = lessonsData.find(l => l.id === lessonId);
    if (lesson && !lesson.locked) {
        lesson.completed = true;
        lesson.progress = 100;
        
        // Unlock the next lesson if it exists
        const nextLesson = lessonsData.find(l => l.id === lessonId + 1);
        if (nextLesson) {
            nextLesson.locked = false;
        }
        
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        
        // Congratulations animation
        if (lessonId === lessonsData.length) {
            alert('🎉 Congratulations! You have completed all beginner level lessons! 🎉');
        } else {
            alert(`✅ Congratulations! You have completed the lesson "${lesson.title}"`);
        }
    }
}

// Setup event listeners
function setupEventListeners() {
    // Filters
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Apply filter
            renderLessons(filter);
        });
    });
}

// Get current filter
function getCurrentFilter() {
    const activeFilter = document.querySelector('.filter-btn.active');
    return activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
}

// Unlock all lessons function (for testing)
function unlockAllLessons() {
    if (confirm("Do you want to unlock all lessons? (Test function)")) {
        lessonsData.forEach(lesson => {
            lesson.locked = false;
        });
        renderLessons(getCurrentFilter());
        alert("All lessons have been unlocked!");
    }
}

// Reset progress function (for testing)
function resetProgress() {
    if (confirm("Do you want to reset all your progress?")) {
        lessonsData.forEach((lesson, index) => {
            lesson.completed = index < 5; // Keep first 5 completed for example
            lesson.progress = lesson.completed ? 100 : 0;
            lesson.locked = index >= 14; // Lock the last lesson
        });
        renderLessons(getCurrentFilter());
        updateGlobalProgress();
        alert("Progress reset!");
    }
}

// Add these functions to console for testing
console.log(`Available functions:
- completeLesson(lessonId) : Mark a lesson as completed
- unlockAllLessons() : Unlock all lessons
- resetProgress() : Reset progress
`);
// Synchronise la progression avec le localStorage
function syncProgressWithLocalStorage() {
    lessonsData.forEach(lesson => {
        const completed = localStorage.getItem(`lesson${lesson.id}-completed`);
        const progress = localStorage.getItem(`lesson${lesson.id}-progress`);
        
        if (completed === 'true') {
            lesson.completed = true;
            lesson.progress = 100;
        } else if (progress) {
            lesson.progress = parseInt(progress);
        }
    });
}

// Appelez cette fonction au chargement
document.addEventListener('DOMContentLoaded', function() {
    syncProgressWithLocalStorage();
    renderLessons();
    updateGlobalProgress();
    setupEventListeners();
});